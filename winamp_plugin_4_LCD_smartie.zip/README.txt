
Please visit our website to read how to install and use this plugin.

  http://lcdsmartie.sourceforge.net/winampplugin.html


Demo Configs
============
A demo config is included in this package, to use rename your config.ini in the Smartie directory and replace with the demo config 'config-winamp.ini'.

NB: The dll check interval and refresh interval are set very low - this is to enable the demo config to give the best possible spectrum analyzer graph. But these settings may be cause too much information to be sent to some types of display - if you have problems, then raise the intervals until the problem is resolved.

Changes
=======
v1.0
	- Alpha2 released as v1.0
Alpha2
	- Override refresh speed in 5.3 beta 4
Alpha1
	- Initial release
