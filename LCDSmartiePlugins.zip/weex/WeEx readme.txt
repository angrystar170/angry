Weather Exchnage(WeEx.dll) plugin for LCD SMARTIE
by Limbo
http:\\www.limbo-online.tk

REQUIREMENTS:
A. LCD Smartie 5.3 beta3 or newer
B. Weather Exchange program. Available for download at http://www.ambientweather.com/weex1.html (freeware)
C. .Net framework
D. Parameters.ini file contained on the dll download package.


INSTALLATION
------------
1. Download an install the Weather Exchange program. Set your preferences and ENABLE data export.
2. Extract the WeEx.dll to LCD Smartie plugins directory.
3. Extract the preferences.ini into a directory or the root of your disk (default position is set to C:\)
4. Configure your LCD Smartie screen to get values from dll.
5. Enjoy!


GENERAL DESCRIPTION
------------------- 
The Weather Exchange program is a free offer from Ambient Weather. 
The program can connect to weather stations around the globe and display live weather information.
The Weather Exchange can export into a csv file the information for further usage. 
The WeEx.dll uses the info provided by this program and display it on LCD Smartie.


INFORMATION
-----------
The first parameter (param1) represents the sensor request (e.g. Temp). The second pararameter is the optional parameter.ini path (default location for paramater.ini is "C:\parameter.ini". 

Follows a list a list of the default sensor calls:

CSV = CSV file version
Year = The year in four digit format (example, 2003)
Month = Month
Day = Day
Hour = Hour (in 24 hour format, example, 15 is 3pm)
Min = Minute
Sec = Second
Wndspd = Windspeed				
WndGst = Wind Gust
WndDr = Wind Direction. Note the default call translate the degrees into direction. If you need to get degrees change the "WndDr" keyword on the parameters.ini file and call it using the new keyword.
Hmdt = Humidity
Temp = Temperature
Bar = Barometer
Rain = Rain Rate (rainfall per hour)
Weather = Current Weather Conditions. Note the default call translate the numeric value to condition description. If you need to get the numerical value change the "Weather" keyword on the parameters.ini file and call it using the new keyword.
WndChl = Wind Chill
Heat = Heat Index
DewPnt = Dew Point



Version 
-------
ver. 1.0


Version Features
----------------
Only two functions available to use.

  function1
  Returns sensor values
  returns special analyzed values when asking for "weather" and "wnddr"


  function20
  returns credits about the dll, version and other info.


USAGE
-----



Function1 Examples

$dll(WeEx.dll,1,temp,) returns the temprature
$dll(WeEx.dll,1,bar,) returns the barometer value
$dll(WeEx.dll,1,weather,) returns the weather condtions
$dll(WeEx.dll,1,wndspd,) returns the wind speed
$dll(WeEx,1,rain,C:\LCDSmartie\parameter.ini) returns the wind speed and get settings from the "C:\LCDSmartie\" folder




Function 20 returns dll information regardless of the parameters just add $dll(splittitle.dll,20,param1,param2) 
and the credits screen will appear.

    NOTE:  in all functions is available a short description of returned string that can be displayed by passing the 
    "about" as param1 and "function" as param2.
    e.g. $dll(WeEx,1,about,function) or $dll(WeE,20,about,function)  



KNOWN BUGS AND LIMITATIONS
--------------------------




CREDITS
-------
Creator: Limbo (Nikos Georgousis)
info@eserver.gr


2005-2010 Limbo networks
.net Powered






