holdnscroll.dll plugin for LCD SMARTIE
http:\\www.eserver.gr

REQUIRES LCD Smartie 5.3 beta3 or newer




INFORMATION
-----------
The first parameter (param1) will be steady on your LCD screen and the second 
text parameter (the second parameter is splitted by the "/" symbol the part after the "/" is the text part)
will scroll into a given length of your LCD (length is given as first part of the 
second parameter before the "/") 
for more information refer to USAGE part of this README.



Version 
-------
0.2
Version changes: Fixed bug with scrolling speed. The text is scrolling with minimum 250 msecs



Version Features
----------------
Only two functions available to use.

  function1
  Keeps first parameter steady, and scrolls the second text parameter 


  function20
  returns credits about the dll, version and other info.


USAGE
-----






Function1 Examples

1.

Syntax
function number,steady part,scrolling length/scrolling text

The following example will keep steady the "about" text and will scroll into 13 boxes of your lcd
the "Created by limbo" text. 

$dll(holdnscroll.dll,1,About ,13/Created By Limbo)



2.

The following example requires the splititle plugin (available from my site) and it keeps steady
the text "Artist:" and scrolls the Artist of the played track into 12 boxes.

$dll(holdnscroll,1,Artist:,12/$dll(splittitle,11,$WinampTitle,-)) 




IMPORTANT NOTE: The "/" Is mandatory in order to pass to parameters to plugin 




Function 20 returns dll information regardless of the parameters just add $dll(splittitle.dll,20,param1,param2) 
and the credits screen will appear.

    NOTE:  in all functions is available a short description of returned string that can be displayed by passing the 
    "about" as param1 and "function" as param2.
    e.g. $dll(holdnscroll,1,about,function) or $dll(holdnscroll,20,about,function)  



KNOWN BUGS AND LIMITATIONS
--------------------------

.The scrolling speed IS NOT the scroll interval given by LCD smartie but the Refresh interval.

.You have to count the first parameter leters (including the spaces contained) and add it to the number of scroll boxes.
 The total MUST NOT EXCEED your LCD Screen length. Otherwise the whole data will scroll and you get a mess!






Creator: Nikos Georgousis aka Limbo
info@eserver.gr
For more go to http://www.eserver.gr





