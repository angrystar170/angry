tinybar.dll plugin for LCD SMARTIE
http://lcdsmartie.sourceforge.net/

Author: Nikos Georgousis


REQUIRES LCD Smartie 5.3 beta3 or newer



INFORMATION
-----------
Displays a vertical bar in one character placeholder


Version 
-------
0.2 UPDATED

Now the plugin takes only one custom character, the function number represents the custom character.
One more style added style 7 ideal for volume level.(thanks to user "fishthecat")
http://www.lansley.co.uk/forum/phpBB2/viewtopic.php?t=546






Version Features
----------------
NINE functions available to use.

  function1
  displays the bar. param1 is the bar value, param2 is the bar style (using the custom character number 1)

  function2
  displays the bar. param1 is the bar value, param2 is the bar style (using the custom character number 2)

  function3
  displays the bar. param1 is the bar value, param2 is the bar style (using the custom character number 3)

  function4
  displays the bar. param1 is the bar value, param2 is the bar style (using the custom character number 4)

  function5
  displays the bar. param1 is the bar value, param2 is the bar style (using the custom character number 5)

  function6
  displays the bar. param1 is the bar value, param2 is the bar style (using the custom character number 6)

  function7
  displays the bar. param1 is the bar value, param2 is the bar style (using the custom character number 7)

  function8
  displays the bar. param1 is the bar value, param2 is the bar style (using the custom character number 8)


  function20
  returns credits 


USAGE
-----
 $dll(tinybar,F,VVVVV,S)
 where F is the function number, VVVVV is the display value (eg cpu usage), and S is the style (1 to 7) 

 
 Examples
	To test it use: $dll(tinybar,1,50,1) or $dll(tinybar,1,90,1)

 Real world examples:
	$dll(tinybar,1,$CPUUsage%,6)
	$dll(volume,2,,)$dll(tinybar,1,$dll(volume,2,,),7)	 >>>>>>>>> (requires volume.dll)



    NOTE:  in all functions is available a short description of returned string that can be displayed by passing "about" as param1 and "function" as param2.
    e.g. $dll(tinybar.dll,1,about,function) or $dll(tinybar.dll,20,about,function)  



Function 20 returns dll information regardless of the parameters just add $dll(tinybar,20,param1,param2) 
and the credits screen will appear.



EXTRA INFO
----------
One of the custom characters must be available on the LCD Module! Most of modules have 8 free custom characters.





CREDITS
-------
Creator: Limbo
lcdsmartie@walla.com

For more goto 
http://www.limbo-online.tk

2006 Limbo Software Solutions
.net Powered






