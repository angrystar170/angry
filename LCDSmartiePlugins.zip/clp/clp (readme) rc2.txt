clp.dll
plugin for LCD Smartie
created by Limbo
(c) 2010 limbo networks

Version 0.2 RC2

fixed bug causing LCD Smartie to crash


INFORMATION
-----------
this plugin gets text data from clipboard



Functions
---------
Only one function available 

Function 1
returns text data from clipboard 



Syntax
------
$dll(clp,1,any,any)
No parameters are needed


Bugs may exist
--------------


please send infos to info@eserver.gr

Author: Nikos Georgousis (aka Limbo)



Source available upon request!








