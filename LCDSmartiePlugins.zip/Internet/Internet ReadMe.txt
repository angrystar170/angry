Internet connectivity plugin version 1.1 for LCD Smartie
FIXED RELEASE!


Creator Limbo
www.eserver.gr
info@eserver.gr


REQUIREMENTS
------------
Requires .NET Framework 2.0


DESCRIPTION
-----------
This plug checks the internet connectivity and returns the status and also a site availability


FUNCTIONS
---------
Five functions available in current version.


Function 1
 Returns the internet connection status by checking the predifined site (http://www.google.com)
 The first parameter can determine the return string as follows:
 if the param1 is 0 the function returns either "www.google.com" either "site not available" 
 if the param1 is 1 the function returns either "Connected" either "Not Connceted"
 if the param1 is 2 the function returns either "Online" either "Offline"
 if the param1 is 3 the function returns either "True" either "False"
 if the param1 is 4 the function returns either "1" either "0"
 if the param1 is 5 the function returns either "WEB OK" either "WEB FAIL"
 in any other case the function returns the param1 for the "Connected" status and the param2 for the "Not Connceted" status.

 examples:
 $dll(Internet,1,2,1)
 $dll(Internet,1,3,1)
 $dll(Internet,1,OK,FAIL)


Function 2
 returns the "Online" or "Offline" messages but requires the site to check (param1)
 example:
 $dll(Internet,2,www.limbo-online.tk, )

Function 3
 returns the "1" or "0" messages but requires the site to check (param1)
 example:
 $dll(Internet,3,www.limbo-online.tk, )

Function 4
 returns the "Site  OK" or "Site Not Available" messages but requires the site to check (param1)
 example:
 $dll(Internet,4,www.limbo-online.tk, )


Function 20
 returns credits




BUGS 
----
Not known (?)


ABOUT
-----
Creator: Nikos Georgousis aka Limbo
info@eserver.gr
For more go to http://www.eserver.gr








