umbrella.exe readme
Created by Nikos Georgousis aka Limbo

REQUIRES 
.net Framework



INFORMATION
-----------
This program is created to integrate with cmd.dll plugin for LCD Smartie and direct.dll for LCD Smartie. 
The program is used to send command to LCD Smartie and change, on the fly, screens and themes and display messages directly to LCD Screen.
The umbrella consists from two parts the command window and the direct write window.

The command window can 
command  LCD Smartie to go to specific themes or screens, 
go to next or previous screen within a theme,
keep a short description about the themes and screens helping th end user to manage the displayed messages.

The drirect write window can
send direct four lines of messages to LCD Smartie,
command LCD Smartie to go to a specific screen,
count the number of characters on a line for better message management.



Program Version 
--------------
1.0.0.4


USAGE
-----
Install the cmd.dll and direct.dll to LCD Smartie and add the necessary commands under the actions tab.
Run the program and use the buttons to switch screens and themes or use the direct write pane to send messages directly to LCD.


CREDITS
-------
Creator: Limbo 
Nikos Georgousis (����� ����������)
info@eserver.gr

For more goto 
http://www.eserver.gr

2005-2010 Limbo networks
.net Powered
