warnif.dll plugin for LCD SMARTIE
http://lcdsmartie.sourceforge.net/

REQUIRES LCD Smartie 5.3 beta3 or newer







INFORMATION
-----------
This dll was check a value with agiven limit or condition.
The plugin works by checking the to value given in the first parameter (param1) seperated by the "/" symbol
The second parameter is used as warning message.
For example using the following line $dll(warnif.dll,1,$Temp1/55,Warning high temp!) the pluging will return 
the value of temp1 while the value doesn't exceeds the given (55) upper limit. 
If temp1 goes higher than upper limit the message "Warning high temp!" will returned by plugin.




IMPORTANT NOTICE
----------------
The format of calling the plugin is $dll(warnif.dll,1,AAA/BBB,WWWWWWWWW)
where the AAA is the value to check, BBB is the limit 
(same type values, if you use strings may not work all functions)
seperated ALWAYS by the "/"symbol and WWWWWWWWW is the message or warning that 
will appear if the condition comes true (string value)!

more information in USAGE section


UPDATE
------
In current version added numerical comparision functions to eliminate bug cause when two numerical values of different character lenght was compared. 
The bug was posted on LCD Smartie forums http://forums.lcdsmartie.org/viewtopic.php?p=13974#13974
Many thanks to caesar for his help



Version 
-------
0.3

Version Features
----------------
thirteenth functions available to use.

  function1
  returns warning if AAA is greater than BBB. otherwise returns the AAA value.


  function2
  returns warning if AAA is smaller than BBB. otherwise returns the AAA value.
         
           
  function3
  returns warning if AAA is equal to BBB. otherwise returns the AAA value.

  
  function4
  returns warning if AAA isnot equal to BBB. otherwise returns the AAA value.  

  
  function11
  returns warning if AAA is greater or equal to BBB. otherwise returns the AAA value.


  function12
  returns warning if AAA is smaller or equal to BBB. otherwise returns the AAA value.






VERSION 0.3 NEW FUNCTIONS BELOW (Numerical comparision functions)


function14
  returns warning if AAA is greater  to BBB. otherwise returns the AAA value.

function15
  returns warning if AAA is smaller to BBB. otherwise returns the AAA value.

function16
  returns warning if AAA is equal to BBB. otherwise returns the AAA value.

function17
  returns warning if AAA is not equal to BBB. otherwise returns the AAA value.

function18
  returns warning if AAA is greater or equal to BBB. otherwise returns the AAA value.

function19
  returns warning if AAA is smaller or equal to BBB. otherwise returns the AAA value.








  function20
  returns credits about the dll, version and other info.


USAGE
-----
All functions must be called with three parameters.
Due limitation of LCD Smartie the two parameters must be seperated with the "/" symbol

with the warnif plugin you can set a level for cpu temp and get a message if temp goes higher or
you can set a level for the fan speed and get a warning if the speed is slower or 
check the usermane logged in to computer and give a hello message depending on username or
think any "if-then" condition and test it...

 Examples
 Temp:  $dll(warnif.dll,1,$Temp1/65,CALL ADMINISTRATOR: 555-4579623)
 User:  $dll(warnif.dll,3,$Username/Administrator, You are the commander!)
 USer:  $dll(warnif.dll,4,$Username/Administrator, You are not admin! Who Are You?)
 Speed: $dll(warnif.dll,2,$FanS1/1000, Slow Fan Speed!)







Function 20 returns dll information regardless of the parameters just add $dll(warnif.dll,20,param1,param2) 
and the credits screen will appear.

    NOTE:  in all functions is available a short description of returned string that can be displayed by passing the 
    "about" as param1 and "function" as param2.
    e.g. $dll(warnif.dll,1,about,function) or $dll(warnif.dll,20,about,function)  



KNOWN BUGS
----------
Not yet. Mail to info@eserver.gr





CREDITS
-------
Creator: Limbo
info@eserver.gr

2005-2010 Limbo networks
.net Powered






